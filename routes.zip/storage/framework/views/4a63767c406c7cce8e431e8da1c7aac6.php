<?php $__env->startSection('title', 'Tenant Aesthetic Pvt Ltd'); ?>

<?php $__env->startSection('content'); ?>



<!-- Start right Content here -->
<div class="main-content">

    <div class="page-content">
        <div class="container-fluid">

            <!-- start page title -->
            <div class="row">
                <div class="col-12">
                    <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                        <h4 class="mb-sm-0 font-size-18">Dashboard</h4>

                    </div>
                </div>
            </div>
            <!-- end page title -->

            <h2>Choose a Package</h2>
            <div class="row">
                <?php $__currentLoopData = $packages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $package): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-4">
                    <div class="card mb-3">
                        <div class="card-body">
                            <h5><?php echo e($package->name); ?></h5>
                            <p>₹<?php echo e($package->price); ?></p>
                            <ul>
                                <li>Data: <?php echo e($package->max_data_mb); ?>MB</li>
                                <li>Properties: <?php echo e($package->max_properties); ?></li>
                                <li>Duration: <?php echo e($package->duration_months); ?> months</li>
                            </ul>
                            <form method="POST" action="<?php echo e(route('choose.package', $package->id)); ?>">
                                <?php echo csrf_field(); ?>
                                <button class="btn btn-primary">Choose Package</button>
                            </form>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>


            <!-- end row -->
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.adminmaster', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\Akash\tenant\resources\views/dashboard.blade.php ENDPATH**/ ?>