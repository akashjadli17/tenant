<?php $__env->startSection('content'); ?>

<div class="main-content">
    <div class="page-content">
        <div class="container-fluid">

            <!-- Page Title -->
            <div class="row">
                <div class="col-12">
                    <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                        <h4 class="mb-sm-0 font-size-18">View Packages</h4>
                    </div>
                </div>
            </div>
 
                <h2>All Packages</h2>
                <a href="<?php echo e(route('admin.packages.create')); ?>" class="btn btn-success mb-3">+ Add Package</a>

                <table class="table">
                    <thead>
                        <tr>
                            <th>Name</th>
                            <th>₹ Price</th>
                            <th>Data (MB)</th>
                            <th>Properties</th>
                            <th>Months</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $packages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $package): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($package->name); ?></td>
                            <td>₹<?php echo e($package->price); ?></td>
                            <td><?php echo e($package->max_data_mb); ?></td>
                            <td><?php echo e($package->max_properties); ?></td>
                            <td><?php echo e($package->duration_months); ?></td>
                            <td>
                                <a href="<?php echo e(route('admin.packages.edit', $package)); ?>"
                                    class="btn btn-sm btn-primary">Edit</a>
                                <form action="<?php echo e(route('admin.packages.destroy', $package)); ?>" method="POST"
                                    class="d-inline" onsubmit="return confirm('Delete this package?');">
                                    <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                    <button class="btn btn-sm btn-danger">Delete</button>
                                </form>
                                <a href="<?php echo e(route('admin.packages.show', $package)); ?>"
                                    class="btn btn-sm btn-info">View</a>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.adminmaster', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\Akash\tenant\resources\views/admin/packages/index.blade.php ENDPATH**/ ?>