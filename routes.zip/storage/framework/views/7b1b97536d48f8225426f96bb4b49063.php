

<?php $__env->startSection('title', 'Units - Tenant Aesthetic Pvt Ltd'); ?>

<?php $__env->startSection('content'); ?>
<script src="https://cdn.tailwindcss.com"></script>

<div class="main-content  p-4">
    <div class="page-content">

        <div class="bg-white p-6 rounded shadow">
            <div class="flex justify-between items-center mb-4">
              <h4 class="text-lg font-bold">Units for Property: <?php echo e($selectedProperty?->name ?? 'N/A'); ?></h4>

                <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#createUnitModal">
                    + Add Unit
                </button>
            </div>

            <?php if($units->count() > 0): ?>
            <div class="overflow-auto">
                <table class="min-w-full border text-sm text-left">
                    <thead class="bg-gray-100">
                        <tr>
                            <th class="px-4 py-2">Unit Name</th>
                            <th class="px-4 py-2">Bedroom</th>
                            <th class="px-4 py-2">Kitchen</th>
                            <th class="px-4 py-2">Bath</th>
                            <th class="px-4 py-2">Rent</th>
                            <th class="px-4 py-2">Deposit</th>
                            <th class="px-4 py-2">Late Fee</th>
                            <th class="px-4 py-2">Notes</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $units; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $unit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr class="border-b">
                            <td class="px-4 py-2"><?php echo e($unit->name); ?></td>
                            <td class="px-4 py-2"><?php echo e($unit->bedroom); ?></td>
                            <td class="px-4 py-2"><?php echo e($unit->kitchen); ?></td>
                            <td class="px-4 py-2"><?php echo e($unit->bath); ?></td>
                            <td class="px-4 py-2"><?php echo e($unit->rent); ?> (<?php echo e(ucfirst($unit->rent_type)); ?>)</td>
                            <td class="px-4 py-2"><?php echo e($unit->deposit_amount); ?> (<?php echo e($unit->deposit_type); ?>)</td>
                            <td class="px-4 py-2"><?php echo e($unit->late_fee_amount); ?> (<?php echo e($unit->late_fee_type); ?>)</td>
                            <td class="px-4 py-2"><?php echo e($unit->notes); ?></td>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
            <?php else: ?>
            <p class="text-gray-600">No units found for this property.</p>
            <?php endif; ?>
        </div>

        
        <?php echo $__env->make('admin.units.create_modal', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    </div>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.adminmaster', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\Akash\tenant\resources\views/admin/units/index.blade.php ENDPATH**/ ?>