<?php $__env->startSection('title', $blog->title . ' | Myraluxa Aesthetic Pvt Ltd'); ?>

<?php $__env->startSection('content'); ?>

<main class="main">

    <div class="site-breadcrumb" style="background: url(<?php echo e(asset('assets/img/breadcrumb/01.jpg')); ?>)">
        <div class="container">
            <h2 class="breadcrumb-title">Blog Details</h2>
            <ul class="breadcrumb-menu">
                <li><a href="<?php echo e(route('blogs')); ?>">Home</a></li>
                <li class="active"><?php echo e($blog->title); ?></li>
            </ul>
        </div>
    </div>

    <div class="blog-single-area pt-70 pb-120">
        <div class="container">
            <div class="row">
                <div class="col-lg-8">
                    <div class="blog-single-wrapper">
                        <div class="blog-single-content">
                            <div class="blog-thumb-img mb-4">
                                <?php if($blog->image): ?>
                                    <img src="<?php echo e(asset('storage/blogs/' . $blog->image)); ?>" alt="Blog Image" class="img-fluid rounded">
                                <?php else: ?>
                                    <img src="<?php echo e(asset('assets/img/blog/default.jpg')); ?>" alt="No Image" class="img-fluid rounded">
                                <?php endif; ?>
                            </div>
                            <h2 class="mb-3"><?php echo e($blog->title); ?></h2>
                            <div class="blog-meta mb-4">
                                <ul class="d-flex flex-wrap gap-4 list-unstyled small">
                                    <li><i class="far fa-user"></i> Admin</li>
                                    <li><i class="far fa-clock"></i> <?php echo e($blog->created_at->format('d M Y')); ?></li>
                                    <li><i class="far fa-eye"></i> <?php echo e(rand(200,1000)); ?> Views</li> 
                                </ul>
                            </div>
                            <div class="blog-content">
                                <?php echo $blog->content; ?>

                            </div>
                        </div>
                    </div>
                </div>

                <!-- Sidebar -->
                <div class="col-lg-4">
                    <aside class="sidebar">

                        <div class="widget search">
                            <h5 class="widget-title">Search</h5>
                            <form class="search-form">
                                <input type="text" class="form-control" placeholder="Search Here...">
                                <button type="submit"><i class="far fa-search"></i></button>
                            </form>
                        </div>

                        <div class="widget recent-post">
                            <h5 class="widget-title">Recent Posts</h5>
                            
                            <?php $__currentLoopData = App\Models\Blog::latest()->take(3)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $recent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="recent-post-single mb-3 d-flex">
                                    <div class="recent-post-img me-3">
                                        <img src="<?php echo e($recent->image ? asset('storage/blogs/' . $recent->image) : asset('assets/img/blog/default.jpg')); ?>" alt="Recent" width="70" class="rounded">
                                    </div>
                                    <div class="recent-post-bio">
                                        <h6><a href="<?php echo e(route('blogs.show', $recent->slug)); ?>"><?php echo e(\Illuminate\Support\Str::limit($recent->title, 50)); ?></a></h6>
                                        <span><i class="far fa-clock"></i> <?php echo e($recent->created_at->format('d M Y')); ?></span>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>

                    </aside>
                </div>
            </div>
        </div>
    </div>

</main>

<?php $__env->stopSection(); ?>
<style>
    .img-fluid {
    /* max-width: 100%; */
    height: auto;
    aspect-ratio: 6 / 3;
    width: 90%;
}
</style>

<?php echo $__env->make('layouts.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\Akash\Myra-skincare\resources\views/blog-details.blade.php ENDPATH**/ ?>