<?php $__env->startSection('title', 'Myraluxa Aesthetic Pvt Ltd'); ?>

<?php $__env->startSection('content'); ?>
<main class="main">
    <div class="site-breadcrumb" style="background: url(assets/img/breadcrumb/01.jpg)">
        <div class="container">
            <h2 class="breadcrumb-title">Our Blog</h2>
            <ul class="breadcrumb-menu">
                <li><a href="<?php echo e(route('admin.index')); ?>">Home</a></li>
                <li class="active">Our Blog</li>
            </ul>
        </div>
    </div>

    <div class="blog-area py-5">
        <div class="container">
            <div class="row">
                <?php $__empty_1 = true; $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="col-md-6 col-lg-4">
                        <div class="blog-item">
                            <div class="blog-item-img">
                                <img src="<?php echo e(asset('storage/blogs/' . $blog->image)); ?>" alt="<?php echo e($blog->title); ?>" class="img-fluid">
                            </div>
                            <div class="blog-item-info">
                                <h4 class="blog-title">
                                    <a href="<?php echo e(route('blogs.show', $blog->slug)); ?>"><?php echo e($blog->title); ?></a>
                                </h4>
                                <p><?php echo Str::limit(strip_tags($blog->content), 100, '...'); ?></p>
                                <a class="blog-btn" href="<?php echo e(route('blogs.show', $blog->slug)); ?>">
                                    Read More <i class="far fa-arrow-right"></i>
                                </a>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <p class="text-center">No blogs found.</p>
                <?php endif; ?>
            </div>

            <div class="pagination-area">
                <?php echo e($blogs->links()); ?>

            </div>
        </div>
    </div>
</main>
<?php $__env->stopSection(); ?>

<style>
    .img-fluid {
    max-width: 100%;
    height: auto;
    aspect-ratio: 3 / 2;
}
</style>

<?php echo $__env->make('layouts.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\Akash\Myra-skincare\resources\views/blogs.blade.php ENDPATH**/ ?>