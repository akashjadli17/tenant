<div class="mb-3">
    <label>Name</label>
    <input type="text" name="name" value="<?php echo e(old('name', $package->name ?? '')); ?>" class="form-control" required>
</div>
<div class="mb-3">
    <label>Price</label>
    <input type="number" name="price" value="<?php echo e(old('price', $package->price ?? '')); ?>" class="form-control" required>
</div>

<div class="mb-3">
    <label>Max Data (MB)</label>
    <input type="number" name="max_data_mb" value="<?php echo e(old('max_data_mb', $package->max_data_mb ?? '')); ?>" class="form-control" required>
</div>
<div class="mb-3">
    <label>Max Properties</label>
    <input type="number" name="max_properties" value="<?php echo e(old('max_properties', $package->max_properties ?? '')); ?>" class="form-control" required>
</div>
<div class="mb-3">
    <label>Duration (months)</label>
    <input type="number" name="duration_months" value="<?php echo e(old('duration_months', $package->duration_months ?? '')); ?>" class="form-control" required>
</div>
<?php /**PATH C:\xampp\htdocs\Akash\tenant\resources\views/admin/packages/form.blade.php ENDPATH**/ ?>