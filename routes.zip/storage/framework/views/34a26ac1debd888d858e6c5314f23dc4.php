

<?php $__env->startSection('title', 'Tenant Aesthetic Pvt Ltd'); ?>

<?php $__env->startSection('content'); ?>
  <script src="https://cdn.tailwindcss.com"></script>

<div class="main-content">
  <div class="page-content">


<button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#createUnitModal">
  Open Create Unit Modal
</button>

<!-- Modal -->
<div class="modal fade" id="createUnitModal" tabindex="-1" aria-labelledby="createUnitLabel" aria-hidden="true">
  <div class="modal-dialog modal-xl">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="createUnitLabel">Create unit</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>

      <div class="modal-body">
        <form class="grid grid-cols-1 md:grid-cols-2 gap-4">

          <!-- Unit Name and Property -->
          <div>
            <label class="form-label">Name</label>
            <input type="text" class="form-control" placeholder="Enter unit name">
          </div>
          <div>
            <label class="form-label">Property</label>
           <select name="property_id" class="form-select">
              <option value="">Select Property</option>
              <?php $__currentLoopData = $properties; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($p->id); ?>" <?php echo e((isset($propertyId) && $propertyId == $p->id) ? 'selected' : ''); ?>>
                      <?php echo e($p->name); ?>

                  </option>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </select>

          </div>

          <!-- Bedroom, Kitchen, Bath -->
          <div>
            <label class="form-label">Bedroom</label>
            <input type="number" class="form-control" placeholder="Enter number of bedroom">
          </div>
          <div>
            <label class="form-label">Kitchen</label>
            <input type="number" class="form-control" placeholder="Enter number of kitchen">
          </div>
          <div>
            <label class="form-label">Bath</label>
            <input type="number" class="form-control" placeholder="Enter number of bath">
          </div>

          <!-- Rent and Rent Type -->
          <div>
            <label class="form-label">Rent</label>
            <input type="text" class="form-control" placeholder="Enter unit rent">
          </div>
          <div>
            <label class="form-label">Rent Type</label>
            <select class="form-select">
              <option>Monthly</option>
              <option>Weekly</option>
            </select>
          </div>

          <!-- Rent Duration -->
          <div class="col-md-12">
            <label class="form-label">Rent Duration</label>
            <input type="number" class="form-control" placeholder="Enter day of month between 1 to 30">
          </div>

          <!-- Deposit Type and Amount -->
          <div>
            <label class="form-label">Deposit Type</label>
            <select class="form-select">
              <option>Fixed</option>
              <option>Percentage</option>
            </select>
          </div>
          <div>
            <label class="form-label">Deposit Amount</label>
            <input type="number" class="form-control" placeholder="Enter deposit amount">
          </div>

          <!-- Late Fee Type and Amount -->
          <div>
            <label class="form-label">Late Fee Type</label>
            <select class="form-select">
              <option>Fixed</option>
              <option>Percentage</option>
            </select>
          </div>
          <div>
            <label class="form-label">Late Fee Amount</label>
            <input type="number" class="form-control" placeholder="Enter late fee amount">
          </div>

          <!-- Incident Receipt Amount -->
          <div class="col-md-12">
            <label class="form-label">Incident Receipt Amount</label>
            <input type="number" class="form-control" placeholder="Enter incident receipt amount">
          </div>

          <!-- Notes -->
          <div class="col-md-12">
            <label class="form-label">Notes</label>
            <textarea class="form-control" rows="3" placeholder="Enter notes"></textarea>
          </div>
        </form>
      </div>

      <div class="modal-footer">
        <button type="button" class="btn btn-success">Create</button>
      </div>
    </div>
  </div>
</div>

<!-- Bootstrap JS Bundle -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

  </div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.adminmaster', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\Akash\tenant\resources\views/admin/units/create.blade.php ENDPATH**/ ?>