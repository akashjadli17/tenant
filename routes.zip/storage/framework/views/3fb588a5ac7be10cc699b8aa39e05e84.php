<?php $__env->startSection('title', 'Edit Mid Category | Myraluxa Aesthetic Pvt Ltd'); ?>

<?php $__env->startSection('content'); ?>
    <div class="main-content">
        <div class="page-content">
            <div class="container-fluid">

                <!-- Page Title -->
                <div class="row mb-4">
                    <div class="col-12">
                        <h4 class="mb-0">Edit Mid Category</h4>
                    </div>
                </div>

                <!-- Form -->
                <form action="<?php echo e(route('mid-categories.update', $midCategory->id)); ?>" method="POST"  enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>

                    <!-- Gender Selection -->
                    <div class="row mb-3">
                        <label class="form-label">Select Gender:</label>
                        <div class="col-md-2">
                            <input type="radio" name="gender_id" value="1"
                                <?php echo e($midCategory->topCategory->gender_id == 1 ? 'checked' : ''); ?>> Men
                        </div>
                        <div class="col-md-2">
                            <input type="radio" name="gender_id" value="2"
                                <?php echo e($midCategory->topCategory->gender_id == 2 ? 'checked' : ''); ?>> Women
                        </div>
                    </div>

                    <!-- Top Category Selection -->
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <label class="form-label">Select Top Category</label>
                            <select name="top_category_id" id="top_category_select" class="form-control" required>
                                <option value="">-- Select Top Category --</option>
                                <?php $__currentLoopData = $topCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $topCategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($topCategory->gender_id == $midCategory->topCategory->gender_id): ?>
                                        <option value="<?php echo e($topCategory->id); ?>"
                                            <?php echo e($topCategory->id == $midCategory->top_category_id ? 'selected' : ''); ?>>
                                            <?php echo e($topCategory->name); ?>

                                        </option>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>

                    <!-- Mid Category Name -->
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <label class="form-label">Mid Category Name</label>
                            <input type="text" name="name" class="form-control" value="<?php echo e($midCategory->name); ?>"
                                placeholder="Enter mid-level category name" required>
                        </div>
                    </div>

                    <div class="row mb-3">
                        <div class="col-md-6">
                            <label class="form-label">Upload New Image</label>
                            <input type="file" name="image" class="form-control" accept="image/*">
                            <?php if($midCategory->image): ?>
                                <img src="<?php echo e(asset('storage/uploads/mid_categories/' . $midCategory->image)); ?>" height="80">
                            <?php endif; ?>
                        </div>
                    </div>

                    


                    <!-- Submit & View Buttons -->
                    <div class="text-start mt-4 mb-4">
                        <button type="submit" class="btn btn-success btn-lg me-3">Update Mid Category</button>
                        <a href="<?php echo e(route('mid-categories.index')); ?>" class="btn btn-primary btn-lg">View Mid Categories</a>
                    </div>
                </form>

            </div>
        </div>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const genderInputs = document.querySelectorAll('input[name="gender_id"]');
            const topCategorySelect = document.getElementById('top_category_select');
            const selectedTopId = "<?php echo e($midCategory->top_category_id); ?>";

            genderInputs.forEach(input => {
                input.addEventListener('change', function() {
                    const genderId = this.value;
                    topCategorySelect.innerHTML = '<option value="">Loading...</option>';

                    fetch(`/admin/get-top-categories/${genderId}`)
                        .then(res => res.json())
                        .then(data => {
                            topCategorySelect.innerHTML =
                                '<option value="">-- Select Top Category --</option>';
                            data.forEach(category => {
                                const option = document.createElement('option');
                                option.value = category.id;
                                option.textContent = category.name;
                                if (category.id == selectedTopId) {
                                    option.selected = true;
                                }
                                topCategorySelect.appendChild(option);
                            });
                        })
                        .catch(() => {
                            topCategorySelect.innerHTML =
                                '<option value="">Failed to load categories</option>';
                        });
                });

                // auto-load top categories on page load if gender is preselected
                if (input.checked) {
                    input.dispatchEvent(new Event('change'));
                }
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.adminmaster', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\Akash\Myra-skincare\resources\views/admin/mid-categories/edit.blade.php ENDPATH**/ ?>