<?php $__env->startSection('content'); ?>

<style>
    .site-breadcrumb {
        padding-top: 40px;
        padding-bottom: 40px;
    }

    /* ==== Fade Gallery Slider ==== */
    .fade-gallery-wrapper {
        position: relative;
        width: 100%;
        height: 400px;
        overflow: hidden;
        border-radius: 8px;
    }

    .fade-gallery-slider {
        position: relative;
        width: 100%;
        height: 100%;
    }

    .fade-gallery-img {
        position: absolute;
        width: 100%;
        height: 100%;
        object-fit: cover;
        top: 0;
        left: 0;
        opacity: 0;
        transition: opacity 1s ease-in-out;
        z-index: 0;
    }

    .fade-gallery-img.active {
        opacity: 1;
        z-index: 1;
    }

    /* ==== Service Summary ==== */
    .service-summary {
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 20px;
        max-width: 1000px;
        margin: 20px auto;
        background-color: #fff;
        gap: 20px;
        flex-wrap: wrap;
    }

    .info-left {
        display: flex;
        flex-direction: column;
        gap: 10px;
        flex: 1;
    }

    .service-title {
        font-size: 20px;
        font-weight: 600;
    }

    .price-time {
        display: flex;
        align-items: center;
        font-size: 16px;
        font-weight: bold;
        flex-wrap: wrap;
    }

    .price-time i {
        margin: 0 8px;
        font-style: normal;
        font-weight: normal;
        color: #888;
    }

    .duration {
        font-weight: normal;
        color: #999;
    }

    .rating {
        display: flex;
        align-items: center;
        font-size: 15px;
        color: #999;
        gap: 6px;
        flex-wrap: wrap;
    }

    .rating .star {
        color: #0a0a23;
        font-size: 18px;
    }

    .add-to-cart {
        background-color: #000;
        color: #fff;
        padding: 12px 30px;
        border: none;
        border-radius: 50px;
        font-size: 14px;
        font-weight: 600;
        cursor: pointer;
        transition: background 0.3s;
        white-space: nowrap;
    }

    .add-to-cart:hover {
        background-color: #333;
    }

    /* ==== Tabs Styling ==== */
    .nav-tabs {
        display: flex;
        justify-content: center;
        border-bottom: 1px solid #ccc;
        gap: 10px;
        flex-wrap: wrap;
    }

    .nav-tabs .nav-link {
        color: #888;
        font-weight: 500;
        padding: 14px 20px;
        border: none;
        border-bottom: 2px solid transparent;
        transition: 0.3s ease;
    }

    .nav-tabs .nav-link:hover {
        color: #000;
        background-color: transparent;
    }

    .nav-tabs .nav-link.active {
        color: #000;
        font-weight: 600;
        border-bottom: 2px solid #000;
    }

    .tab-content {
        padding-top: 40px;
    }

    .tab-pane img {
        /* width: 120px; */
        margin-bottom: 20px;
    }

    .tab-pane h5 {
        font-weight: 600;
        margin-bottom: 10px;
    }

    .tab-pane p {
        font-size: 15px;
        margin-bottom: 20px;
        color: black;
    }

    .tab-pane .btn {
        font-size: 14px;
        font-weight: 500;
        padding: 10px 25px;
        border-radius: 25px;
        transition: 0.3s ease;
    }

    /* =================== MOBILE VIEW =================== */
    @media (max-width: 991px) {
        .site-breadcrumb {
            padding-top: 85px;
        }

        .fade-gallery-wrapper {
            height: 200px;
        }

        .service-summary {
            flex-direction: column;
            align-items: flex-start;
            text-align: left;
            gap: 15px;
        }

        .add-to-cart {
            width: 100%;
            text-align: center;
        }

        .price-time,
        .rating {
            font-size: 14px;
        }

        .service-title {
            font-size: 18px;
        }

        .fade-gallery-img {
            object-position: center;
        }
    }

    @media (max-width: 768px) {
        .nav-tabs {
            flex-direction: column;
            align-items: center;
        }

        .nav-tabs .nav-link {
            width: 100%;
            text-align: center;
        }

        .tab-content {
            padding: 20px 10px;
        }

        .tab-pane .btn {
            width: 100%;
            max-width: 250px;
        }

        .tab-pane img {
            width: 100px;
        }

        .service-summary {
            padding: 15px;
        }

        .tab-pane p {
            font-size: 14px;
        }
    }
</style>
<main class="main">
    <div class="site-breadcrumb">
        <div class="container">
            <h2 class="breadcrumb-title"><?php echo e($service->name); ?></h2>
            <ul class="breadcrumb-menu">
                <li><a href="/">Home</a></li>
                <li class="active"><?php echo e($service->name); ?></li>
            </ul>
        </div>
    </div>

    <div class="service-single-area py-5">
        <div class="container">
            <div class="service-single-wrapper">
                <div class="row flex-row-reverse">
                    <div class="col-xl-8 col-lg-8">
                        <div class="service-details">
                            <?php if($service->image): ?>
                            <div class="fade-gallery-wrapper">
                                <div class="fade-gallery-slider">
                                    <img src="<?php echo e(asset('storage/services/images/'.$service->image)); ?>" class="fade-gallery-img active" alt="gallery">
                                    <?php if($service->video): ?>
                                    <img src="<?php echo e(asset('storage/services/images/'.$service->video)); ?>" class="fade-gallery-img" alt="gallery">
                                    <?php endif; ?>
                                </div>
                            </div>
                            <?php endif; ?>
                            <div class="service-summary">
                                <div class="info-left">
                                    <div class="service-title"><?php echo e($service->name); ?></div>
                                    <div class="price-time">Rs. <?php echo e($service->price); ?> &nbsp; | &nbsp; <i class="far fa-clock"></i> <?php echo e($service->duration); ?> mins</div>
                                    <div class="rating">
                                        <span class="star">&#9733;</span>
                                        <span><?php echo e($service->rating ?? '4.85'); ?></span>
                                    </div>
                                </div>
                                <button class="add-to-cart">ADD TO CART</button>
                            </div>

                            <ul class="nav nav-tabs justify-content-center" id="bookingTabs" role="tablist">
                                <li class="nav-item" role="presentation">
                                    <button class="nav-link active" id="services-tab" data-bs-toggle="tab" data-bs-target="#services" type="button" role="tab">OVERVIEW</button>
                                </li>
                                <li class="nav-item" role="presentation">
                                    <button class="nav-link" id="how-tab" data-bs-toggle="tab" data-bs-target="#how" type="button" role="tab">HOW IT WORKS</button>
                                </li>
                                <li class="nav-item" role="presentation">
                                    <button class="nav-link" id="faq-tab" data-bs-toggle="tab" data-bs-target="#faq" type="button" role="tab">FAQ'S</button>
                                </li>
                            </ul>

                            <div class="tab-content py-5">
                                <div class="tab-pane fade show active" id="services" role="tabpanel">
                                    <?php echo $service->overview; ?>

                                </div>
                                <div class="tab-pane fade" id="how" role="tabpanel">
                                    <div class="row text-center">
                                        <?php $__currentLoopData = $service->how_it_works ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $step): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="col-md-6">
                                            <img src="<?php echo e(asset('storage/services/how_it_works/'.$step['image'])); ?>" alt="">
                                            <p><?php echo e($step['title']); ?></p>
                                        </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                </div>
                                <div class="tab-pane fade" id="faq" role="tabpanel">
                                    <div class="accordion" id="accordionFaq">
                                        <?php $__currentLoopData = $service->faqs ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $faq): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="accordion-item">
                                            <h2 class="accordion-header" id="heading<?php echo e($index); ?>">
                                                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapse<?php echo e($index); ?>">
                                                    <?php echo e($faq['question']); ?>

                                                </button>
                                            </h2>
                                            <div id="collapse<?php echo e($index); ?>" class="accordion-collapse collapse" data-bs-parent="#accordionFaq">
                                                <div class="accordion-body">
                                                    <?php echo e($faq['answer']); ?>

                                                </div>
                                            </div>
                                        </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-xl-4 col-lg-4">
                        <div class="service-sidebar">
                            <div class="widget category">
                                <h4 class="widget-title">All Services</h4>
                                <div class="category-list">
                                    <?php $__currentLoopData = App\Models\Service::take(8)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <a href="<?php echo e(route('service.detail', Str::slug($s->name))); ?>">
                                        <i class="far fa-angle-double-right"></i> <?php echo e($s->name); ?>

                                    </a>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>
</main>

<script>
    // JavaScript to rotate images every 3 seconds
    let current = 0;
    const slides = document.querySelectorAll('.fade-gallery-img');

    setInterval(() => {
        slides[current].classList.remove('active');
        current = (current + 1) % slides.length;
        slides[current].classList.add('active');
    }, 3000);
</script>
<!-- end slider -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\Akash\Myra-skincare\resources\views/service-detail.blade.php ENDPATH**/ ?>