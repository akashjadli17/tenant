<?php $__env->startSection('title', 'Women Categories'); ?>

<?php $__env->startSection('content'); ?>

<main class="main">

    <div class="site-breadcrumb" style="background: url(assets/img/breadcrumb/01.jpg)">
        <div class="container">
            <h2 class="breadcrumb-title">Women Category</h2>
            <ul class="breadcrumb-menu">
                <li><a href="/">Home</a></li>
                <li class="active">Women Category</li>
            </ul>
        </div>
    </div>

    <div class="team-area pt-4">
        <div class="container">

            
            <ul class="nav nav-tabs justify-content-center mb-4" role="tablist">
                <?php $__currentLoopData = $topCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $topCat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="nav-item">
                        <button class="nav-link <?php if($index === 0): ?> active <?php endif; ?>"
                                data-bs-toggle="tab"
                                data-bs-target="#tab-<?php echo e($topCat->id); ?>"
                                type="button"
                                role="tab">
                            <?php echo e($topCat->name); ?>

                        </button>
                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>

            
            <div class="tab-content">
                <?php $__currentLoopData = $topCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $topCat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="tab-pane fade <?php if($index === 0): ?> show active <?php endif; ?>"
                         id="tab-<?php echo e($topCat->id); ?>"
                         role="tabpanel">

                        <div class="row justify-content-center">
                            <?php $__currentLoopData = $topCat->midCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $midCat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="col-6 col-md-6 col-lg-3 mb-4">
                                    <div class="team-item text-center">
                                        <img src="<?php echo e(asset('storage/uploads/mid_categories/' . $midCat->image)); ?>"
                                             alt="<?php echo e($midCat->name); ?>"
                                             class="img-fluid mb-2">
                                        <div class="team-content">
                                            <div class="team-bio">
                                                <h5><a href="#"><?php echo e($midCat->name); ?></a></h5>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>

                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

        </div>
    </div>

</main>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\Akash\Myra-skincare\resources\views/women.blade.php ENDPATH**/ ?>