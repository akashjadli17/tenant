
<?php $__env->startSection('title', 'Tenant List'); ?>

<?php $__env->startSection('content'); ?>
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">

<div class="main-content  p-4">
    <div class="page-content">


        <div class="container-fluid py-4">
            <div class="d-flex justify-content-between mb-4">
                <h2>Tenant List</h2>
                <a href="<?php echo e(route('tenants.create')); ?>" class="btn btn-success">+ Create Tenant</a>
            </div>

            <?php if(session('success')): ?>
            <div class="alert alert-success mb-3"><?php echo e(session('success')); ?></div>
            <?php endif; ?>

            <div class="row">
                <?php $__currentLoopData = $tenants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tenant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-3 mb-4">
                    <div class="card shadow p-3">
                        <td>
                            <div class="dropdown text-end">
                                <button class="btn btn-light btn-sm" type="button" data-bs-toggle="dropdown"
                                    aria-expanded="false">
                                    <i class="bi bi-three-dots-vertical"> </i>
                                </button>
                                <ul class="dropdown-menu dropdown-menu-end">
                                    <li>
                                        <a href="<?php echo e(route('tenants.show', $tenant->id)); ?>" class="dropdown-item">
                                            <i class="bi bi-eye me-2"></i> View
                                        </a>
                                    </li>
                                    <li>
                                        <a href="<?php echo e(route('tenants.edit', $tenant->id)); ?>" class="dropdown-item">
                                            <i class="bi bi-pencil me-2"></i> Edit
                                        </a>
                                    </li>
                                    <li>
                                        <form action="<?php echo e(route('tenants.destroy', $tenant->id)); ?>" method="POST"
                                            onsubmit="return confirm('Are you sure you want to delete this tenant?');">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button class="dropdown-item text-danger" type="submit">
                                                <i class="bi bi-trash me-2"></i> Delete
                                            </button>
                                        </form>
                                    </li>
                                </ul>
                            </div>
                        </td>

                        <img src="<?php echo e($tenant->profile ? asset('storage/' . $tenant->profile) : 'https://via.placeholder.com/100'); ?>"
                            class="w-25 h-25 mx-auto rounded-circle mb-2" />
                        <h5 class="text-center"><?php echo e($tenant->first_name); ?> <?php echo e($tenant->last_name); ?></h5>
                        <p class="text-center text-sm text-muted"><?php echo e($tenant->email); ?></p>
                        <p class="text-center text-sm"><?php echo e($tenant->address); ?></p>
                        <div class="text-sm mt-2">
                            <p><strong>Phone:</strong> <?php echo e($tenant->phone_number); ?></p>
                            <p><strong>Family:</strong> <?php echo e($tenant->total_family_member); ?></p>
                            <p><strong>Property:</strong> <?php echo e($tenant->property->name); ?></p>
                            <p><strong>Unit:</strong> <?php echo e($tenant->unit->name); ?></p>
                            <p><strong>Start:</strong> <?php echo e($tenant->lease_start_date->format('M d, Y')); ?></p>
                            <p><strong>End:</strong> <?php echo e($tenant->lease_end_date->format('M d, Y')); ?></p>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>

    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.adminmaster', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\Akash\tenant\resources\views/tenants/index.blade.php ENDPATH**/ ?>