<?php $__env->startSection('title', 'Edit Service | Myraluxa Aesthetic Pvt Ltd'); ?>

<?php $__env->startSection('content'); ?>
    <div class="main-content">
        <div class="page-content">
            <div class="container-fluid">

                <!-- Page Title -->
                <div class="row mb-4">
                    <div class="col-12">
                        <h4 class="mb-0">Edit Service</h4>
                    </div>
                </div>

                <form action="<?php echo e(route('services.update', $service->id)); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>

                    <!-- Gender Selection -->
                    <div class="row mb-3">
                        <label class="form-label">Select Gender:</label>
                        <div class="col-md-2">
                            <input type="radio" name="gender_id" value="1"
                                <?php echo e(optional(optional($service->midCategory->topCategory)->gender)->id == 1 ? 'checked' : ''); ?>>
                            Men
                        </div>
                        <div class="col-md-2">
                            <input type="radio" name="gender_id" value="2"
                                <?php echo e(optional(optional($service->midCategory->topCategory)->gender)->id == 2 ? 'checked' : ''); ?>>
                            Women
                        </div>
                    </div>



                    <!-- Category Dropdowns -->
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <label class="form-label">Top Level Category</label>
                            <select name="top_category_id" id="top_category" class="form-control" required>
                                <option value="">-- Select Top Category --</option>
                                <?php $__currentLoopData = $topCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $top): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($top->id); ?>"
                                        <?php echo e($top->id == optional($service->midCategory->topCategory)->id ? 'selected' : ''); ?>>
                                        <?php echo e($top->name); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>

                        <div class="col-md-6">
                            <label class="form-label">Mid Level Category</label>
                            <select name="mid_category_id" id="mid_category" class="form-control" required>
                                <option value="">-- Select Mid Category --</option>

                                <?php if($service->midCategory && $service->midCategory->top_category_id == optional($service->midCategory->topCategory)->id): ?>
                                    <option value="<?php echo e($service->midCategory->id); ?>" selected>
                                        <?php echo e($service->midCategory->name); ?>

                                    </option>
                                <?php endif; ?>
                            </select>
                        </div>
                    </div>


                    <!-- Service Details -->
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <label class="form-label">Service Name</label>
                            <input type="text" name="name" class="form-control" value="<?php echo e($service->name); ?>" required>
                        </div>
                        <div class="col-md-3">
                            <label class="form-label">Price</label>
                            <input type="number" name="price" step="0.01" class="form-control"
                                value="<?php echo e($service->price); ?>">
                        </div>
                        <div class="col-md-3">
                            <label class="form-label">Rating</label>
                            <input type="number" name="rating" step="0.1" max="5" min="0"
                                class="form-control" value="<?php echo e($service->rating); ?>">
                        </div>
                    </div>

                    <div class="row mb-3">
                        <div class="col-md-4">
                            <label class="form-label">Duration (in min)</label>
                            <input type="text" name="duration" class="form-control" value="<?php echo e($service->duration); ?>">
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">Services Image</label>
                            <input type="file" name="image" class="form-control" accept="image/*">
                            <?php if($service->image): ?>
                                <img src="<?php echo e(asset('storage/services/images/' . $service->image)); ?>" width="80"
                                    class="mt-2">
                            <?php endif; ?>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">Services Video</label>
                            <input type="file" name="video" class="form-control" accept="video/*">
                            <?php if($service->video): ?>
                                <video width="100" controls class="mt-2">
                                    <source src="<?php echo e(asset('storage/services/videos/' . $service->video)); ?>">
                                </video>
                            <?php endif; ?>
                        </div>
                    </div>

                    <div class="mb-3">
                        <label class="form-label">Service Highlight Points</label>
                        <textarea name="highlight_points" class="form-control" rows="2"><?php echo e($service->highlight_points); ?></textarea>
                    </div>

                    <div class="mb-3">
                        <label class="form-label">Service Overview</label>
                        <textarea name="overview" class="form-control" rows="4"><?php echo e($service->overview); ?></textarea>
                    </div>

                    <!-- How It Works -->
                    <div class="mb-3">
                        <label class="form-label">How It Works</label>
                        <div id="how-it-works-wrapper">
                            <?php $__currentLoopData = $service->how_it_works; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="row how-it-works-item mb-2">
                                    <div class="col-md-5">
                                        <input type="file" name="how_it_works_images[]" class="form-control">
                                        <?php if(!empty($item['image'])): ?>
                                            <small>Current: <?php echo e($item['image']); ?></small>
                                        <?php endif; ?>
                                    </div>
                                    <div class="col-md-5">
                                        <input type="text" name="how_it_works_titles[]" class="form-control"
                                            placeholder="Image Title" value="<?php echo e($item['title'] ?? ''); ?>">
                                    </div>
                                    <div class="col-md-2">
                                        <button type="button" class="btn btn-danger remove-how-it-works">Remove</button>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                        <button type="button" class="btn btn-info mt-2" id="add-how-it-works">+ Add More</button>
                    </div>

                    <!-- FAQ Section -->
                    <div class="mb-3">
                        <label class="form-label">FAQ Section</label>
                        <div id="faq-wrapper">
                            <?php if($service->faq): ?>
                                <?php $__currentLoopData = $service->faqs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $faq): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="row faq-item mb-2">
                                        <div class="col-md-5">
                                            <input type="text" name="faq_questions[]" class="form-control"
                                                placeholder="Enter Question" value="<?php echo e($faq['question'] ?? ''); ?>">
                                        </div>
                                        <div class="col-md-5">
                                            <input type="text" name="faq_answers[]" class="form-control"
                                                placeholder="Enter Answer" value="<?php echo e($faq['answer'] ?? ''); ?>">
                                        </div>
                                        <div class="col-md-2">
                                            <button type="button" class="btn btn-danger remove-faq">Remove</button>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </div>
                        <button type="button" class="btn btn-warning mt-2" id="add-faq">+ Add FAQ</button>
                    </div>


                    <!-- Submit -->
                    <div class="text-center mt-4 mb-4">
                        <button type="submit" class="btn btn-success btn-lg me-3">Update Service</button>
                        <a href="<?php echo e(route('services.index')); ?>" class="btn btn-primary btn-lg">Back to Services</a>
                    </div>

                </form>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script>
        $(document).ready(function() {
            // Add How it Works
            $('#add-how-it-works').click(function() {
                $('#how-it-works-wrapper').append(`
                    <div class="row how-it-works-item mb-2">
                        <div class="col-md-5">
                            <input type="file" name="how_it_works_images[]" class="form-control">
                        </div>
                        <div class="col-md-5">
                            <input type="text" name="how_it_works_titles[]" class="form-control" placeholder="Image Title">
                        </div>
                        <div class="col-md-2">
                            <button type="button" class="btn btn-danger remove-how-it-works">Remove</button>
                        </div>
                    </div>
                `);
            });

            $(document).on('click', '.remove-how-it-works', function() {
                $(this).closest('.how-it-works-item').remove();
            });

            // Add FAQ
            $('#add-faq').click(function() {
                $('#faq-wrapper').append(`
                    <div class="row faq-item mb-2">
                        <div class="col-md-5">
                            <input type="text" name="faq_questions[]" class="form-control" placeholder="Enter Question">
                        </div>
                        <div class="col-md-5">
                            <input type="text" name="faq_answers[]" class="form-control" placeholder="Enter Answer">
                        </div>
                        <div class="col-md-2">
                            <button type="button" class="btn btn-danger remove-faq">Remove</button>
                        </div>
                    </div>
                `);
            });

            $(document).on('click', '.remove-faq', function() {
                $(this).closest('.faq-item').remove();
            });

            // Mid Category Loading Logic
            const currentMidCategoryId = '<?php echo e($service->mid_category_id); ?>';
            const currentTopCategoryId = '<?php echo e($service->top_category_id); ?>';

            function loadMidCategories(topId, selectedMidId = null) {
                fetch(`/admin/get-mid-categories/${topId}`)
                    .then(res => res.json())
                    .then(data => {
                        let options = '<option value="">-- Select Mid Category --</option>';
                        data.forEach(cat => {
                            const selected = (cat.id == selectedMidId) ? 'selected' : '';
                            options += `<option value="${cat.id}" ${selected}>${cat.name}</option>`;
                        });
                        $('#mid_category').html(options);
                    });
            }

            // On top category change
            $('#top_category').on('change', function() {
                const topId = $(this).val();
                loadMidCategories(topId);
            });

            // Initial load
            loadMidCategories(currentTopCategoryId, currentMidCategoryId);
        });
        const currentMidCategoryId = '<?php echo e($service->mid_category_id); ?>';
        const currentTopCategoryId = '<?php echo e(optional($service->midCategory->topCategory)->id); ?>';
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.adminmaster', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\Akash\Myra-skincare\resources\views/admin/services/edit.blade.php ENDPATH**/ ?>