<?php $__env->startSection('content'); ?><div class="main-content">
    <div class="page-content">
        <div class="container-fluid">


            <h2>Create Package</h2>
            <form method="POST" action="<?php echo e(route('admin.packages.store')); ?>">
                <?php echo csrf_field(); ?>
                <?php echo $__env->make('admin.packages.form', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                <button type="submit" class="btn btn-success">Create</button>
            </form>
        </div>

    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.adminmaster', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\Akash\tenant\resources\views/admin/packages/create.blade.php ENDPATH**/ ?>