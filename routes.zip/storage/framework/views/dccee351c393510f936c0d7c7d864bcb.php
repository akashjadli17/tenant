<!-- Create Unit Modal -->
<div class="modal fade" id="createUnitModal" tabindex="-1" aria-labelledby="createUnitLabel" aria-hidden="true">
    <div class="modal-dialog modal-xl">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="createUnitLabel">Create Unit</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>

            <form action="<?php echo e(route('units.store')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div class="modal-body">
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <!-- Unit Name -->
                        <div>
                            <label class="form-label">Name <span class="text-danger">*</span></label>
                            <input type="text" name="name" class="form-control" value="<?php echo e(old('name')); ?>" required>
                            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="text-danger"><?php echo e($message); ?></small> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <!-- Property -->
                        <div>
                            <label class="form-label">Property <span class="text-danger">*</span></label>
                            <select name="property_id" class="form-select" required>
                                <option value="">Select Property</option>
                                <?php $__currentLoopData = $properties; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($p->id); ?>" <?php echo e(old('property_id', $propertyId ?? '') == $p->id ? 'selected' : ''); ?>>
                                        <?php echo e($p->name); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php $__errorArgs = ['property_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="text-danger"><?php echo e($message); ?></small> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <!-- Bedroom -->
                        <div>
                            <label class="form-label">Bedroom</label>
                            <input type="number" name="bedroom" class="form-control" value="<?php echo e(old('bedroom')); ?>">
                            <?php $__errorArgs = ['bedroom'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="text-danger"><?php echo e($message); ?></small> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <!-- Kitchen -->
                        <div>
                            <label class="form-label">Kitchen</label>
                            <input type="number" name="kitchen" class="form-control" value="<?php echo e(old('kitchen')); ?>">
                            <?php $__errorArgs = ['kitchen'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="text-danger"><?php echo e($message); ?></small> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <!-- Bath -->
                        <div>
                            <label class="form-label">Bath</label>
                            <input type="number" name="bath" class="form-control" value="<?php echo e(old('bath')); ?>">
                            <?php $__errorArgs = ['bath'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="text-danger"><?php echo e($message); ?></small> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <!-- Rent -->
                        <div>
                            <label class="form-label">Rent <span class="text-danger">*</span></label>
                            <input type="text" name="rent" class="form-control" value="<?php echo e(old('rent')); ?>" required>
                            <?php $__errorArgs = ['rent'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="text-danger"><?php echo e($message); ?></small> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <!-- Rent Type -->
                        <div>
                            <label class="form-label">Rent Type <span class="text-danger">*</span></label>
                            <select name="rent_type" class="form-select" required>
                                <option value="">Select Type</option>
                                <option value="monthly" <?php echo e(old('rent_type') == 'monthly' ? 'selected' : ''); ?>>Monthly</option>
                                <option value="weekly" <?php echo e(old('rent_type') == 'weekly' ? 'selected' : ''); ?>>Weekly</option>
                            </select>
                            <?php $__errorArgs = ['rent_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="text-danger"><?php echo e($message); ?></small> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <!-- Rent Duration -->
                        <div class="col-md-12">
                            <label class="form-label">Rent Duration (Day of Month)</label>
                            <input type="number" name="rent_duration" class="form-control" value="<?php echo e(old('rent_duration')); ?>" placeholder="Enter day of month between 1 to 30">
                            <?php $__errorArgs = ['rent_duration'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="text-danger"><?php echo e($message); ?></small> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <!-- Deposit Type -->
                        <div>
                            <label class="form-label">Deposit Type <span class="text-danger">*</span></label>
                            <select name="deposit_type" class="form-select" required>
                                <option value="">Select Type</option>
                                <option value="fixed" <?php echo e(old('deposit_type') == 'fixed' ? 'selected' : ''); ?>>Fixed</option>
                                <option value="percentage" <?php echo e(old('deposit_type') == 'percentage' ? 'selected' : ''); ?>>Percentage</option>
                            </select>
                            <?php $__errorArgs = ['deposit_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="text-danger"><?php echo e($message); ?></small> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <!-- Deposit Amount -->
                        <div>
                            <label class="form-label">Deposit Amount <span class="text-danger">*</span></label>
                            <input type="number" name="deposit_amount" class="form-control" value="<?php echo e(old('deposit_amount')); ?>" required>
                            <?php $__errorArgs = ['deposit_amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="text-danger"><?php echo e($message); ?></small> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <!-- Late Fee Type -->
                        <div>
                            <label class="form-label">Late Fee Type <span class="text-danger">*</span></label>
                            <select name="late_fee_type" class="form-select" required>
                                <option value="">Select Type</option>
                                <option value="fixed" <?php echo e(old('late_fee_type') == 'fixed' ? 'selected' : ''); ?>>Fixed</option>
                                <option value="percentage" <?php echo e(old('late_fee_type') == 'percentage' ? 'selected' : ''); ?>>Percentage</option>
                            </select>
                            <?php $__errorArgs = ['late_fee_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="text-danger"><?php echo e($message); ?></small> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <!-- Late Fee Amount -->
                        <div>
                            <label class="form-label">Late Fee Amount <span class="text-danger">*</span></label>
                            <input type="number" name="late_fee_amount" class="form-control" value="<?php echo e(old('late_fee_amount')); ?>" required>
                            <?php $__errorArgs = ['late_fee_amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="text-danger"><?php echo e($message); ?></small> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <!-- Incident Receipt Amount -->
                        <div class="col-md-12">
                            <label class="form-label">Incident Receipt Amount</label>
                            <input type="number" name="incident_receipt_amount" class="form-control" value="<?php echo e(old('incident_receipt_amount')); ?>">
                            <?php $__errorArgs = ['incident_receipt_amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="text-danger"><?php echo e($message); ?></small> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <!-- Notes -->
                        <div class="col-md-12">
                            <label class="form-label">Notes</label>
                            <textarea name="notes" class="form-control" rows="3"><?php echo e(old('notes')); ?></textarea>
                            <?php $__errorArgs = ['notes'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="text-danger"><?php echo e($message); ?></small> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                </div>

                <div class="modal-footer">
                    <button type="submit" class="btn btn-success">Create</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Auto-Open Modal if Validation Errors Exist -->
<?php if($errors->any()): ?>
<script>
    document.addEventListener("DOMContentLoaded", function () {
        const modal = new bootstrap.Modal(document.getElementById('createUnitModal'));
        modal.show();
    });
</script>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\Akash\tenant\resources\views/admin/units/create_modal.blade.php ENDPATH**/ ?>