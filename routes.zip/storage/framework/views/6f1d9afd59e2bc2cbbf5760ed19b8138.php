

<?php $__env->startSection('content'); ?>
<div class="container">
    <h2><?php echo e($package->name); ?></h2>
    <ul>
        <li>Price: ₹<?php echo e($package->price); ?></li>
        <li>Max Data: <?php echo e($package->max_data_mb); ?> MB</li>
        <li>Max Properties: <?php echo e($package->max_properties); ?></li>
        <li>Duration: <?php echo e($package->duration_months); ?> months</li>
    </ul>
    <a href="<?php echo e(route('admin.packages.index')); ?>" class="btn btn-secondary">Back</a>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.adminmaster', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\Akash\tenant\resources\views/admin/packages/show.blade.php ENDPATH**/ ?>