<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title><?php echo $__env->yieldContent('title', 'Myra Skincare'); ?></title>
    <link rel="icon" type="image/x-icon" href="<?php echo e(asset('assets/img/logo/favicon.png')); ?>">

    <!-- CSS Files -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/dashboard/css/bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/dashboard/css/icons.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/dashboard/css/app.min.css')); ?>">

 

    <!-- JS Plugin (if needed early) -->
    <script src="<?php echo e(asset('assets/dashboard/js/plugin.js')); ?>"></script>

    <!-- Extra head section -->
    <?php echo $__env->yieldPushContent('head'); ?>
</head>

<body>

    <!-- Admin Header -->
    <?php echo $__env->make('layouts.adminheader', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php echo $__env->make('layouts.adminmaster-sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>


    <!-- Main Content -->
    <div class="content">
        <?php echo $__env->yieldContent('content'); ?>
    </div>

    <!-- Admin Footer -->
    <?php echo $__env->make('layouts.adminfooter', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <!-- Additional Scripts -->
    <?php echo $__env->yieldPushContent('scripts'); ?>
</body>

</html><?php /**PATH C:\xampp\htdocs\Akash\tenant\resources\views/layouts/adminmaster.blade.php ENDPATH**/ ?>