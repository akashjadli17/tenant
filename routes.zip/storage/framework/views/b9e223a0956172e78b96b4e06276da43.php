<?php $__env->startSection('title', 'Edit Profile'); ?>

<?php $__env->startSection('content'); ?>



<main class="main">

    <div class="container py-5">
        <div class="row align-items-center">
            <!-- Carousel Section -->
            <div class="col-lg-6">
                <div class="fade-gallery-wrapper">
                    <div class="fade-gallery-slider">
                        <img src="<?php echo e(asset('assets/img/slider/edit_slider.png')); ?>" class="fade-gallery-img active"
                            alt="gallery">
                        <img src="<?php echo e(asset('assets/img/slider/edit_slider1.webp')); ?>" class="fade-gallery-img"
                            alt="gallery">
                    </div>
                </div>
            </div>


            <div class="container max-w-xl mx-auto p-4">
                <h2 class="text-xl font-bold mb-4">My Profile</h2>

                <?php if(session('success')): ?>
                <div class="bg-green-100 text-green-700 p-2 rounded mb-3">
                    <?php echo e(session('success')); ?>

                </div>
                <?php endif; ?>

                <form action="<?php echo e(route('profile.update')); ?>" method="POST" enctype="multipart/form-data"
                    class="space-y-4">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PATCH'); ?>

                    <div>
                        <label class="block font-medium">Name</label>
                        <input type="text" name="name" value="<?php echo e(old('name', $user->name)); ?>"
                            class="border border-gray-300 rounded w-full p-2">
                        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-600"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div>
                        <label class="block font-medium">Email</label>
                        <input type="email" value="<?php echo e($user->email); ?>" class="bg-gray-100 border rounded w-full p-2"
                            disabled>
                    </div>

                    <div>
                        <label class="block font-medium">Phone</label>
                        <input type="text" name="phone" value="<?php echo e(old('phone', $user->phone)); ?>"
                            class="border border-gray-300 rounded w-full p-2">
                        <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-600"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div>
                        <label class="block font-medium">Gender</label>
                        <select name="gender" class="border border-gray-300 rounded w-full p-2">
                            <option value="">-- Select --</option>
                            <option value="male" <?php echo e($user->gender == 'male' ? 'selected' : ''); ?>>Male</option>
                            <option value="female" <?php echo e($user->gender == 'female' ? 'selected' : ''); ?>>Female</option>
                            <option value="other" <?php echo e($user->gender == 'other' ? 'selected' : ''); ?>>Other</option>
                        </select>
                        <?php $__errorArgs = ['gender'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-600"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div>
                        <label class="block font-medium">Profile Image</label>
                        <?php if($user->profile_image): ?>
                        <img src="<?php echo e(asset('storage/profiles/' . $user->profile_image)); ?>" alt="Profile Image"
                            class="w-24 h-24 rounded-full mb-2">
                        <?php endif; ?>
                        <input type="file" name="profile_image" class="block">
                        <?php $__errorArgs = ['profile_image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-600"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <button type="submit" class="bg-blue-600 text-white px-4 py-2 rounded">Update Profile</button>
                </form>
            </div>

        </div>
    </div>

</main>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.adminmaster', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\Akash\tenant\resources\views/profile/edit.blade.php ENDPATH**/ ?>