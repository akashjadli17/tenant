<style>
    
:root {
    --primary-color: #4e73df;
    --secondary-color: #f8f9fc;
    --accent-color: #2e59d9;
    --text-color: #5a5c69;
}

body {
    background-color: var(--secondary-color);
    color: var(--text-color);
    font-family: 'Nunito', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;
}

.booking-container {
    max-width: 1000px;
    margin: 50px auto;
    background: white;
    border-radius: 10px;
    box-shadow: 0 0.15rem 1.75rem 0 rgba(58, 59, 69, 0.15);
    overflow: hidden;
}

.booking-header {
    background: var(--primary-color);
    color: white;
    padding: 20px;
    text-align: center;
}

.booking-steps {
    display: flex;
    justify-content: space-between;
    padding: 20px;
    background-color: #f1f3f9;
}

.step {
    display: flex;
    flex-direction: column;
    align-items: center;
    position: relative;
    z-index: 1;
    margin-right: 20px;
}

.step-number {
    width: 40px;
    height: 40px;
    border-radius: 50%;
    background-color: #e0e0e0;
    display: flex;
    align-items: center;
    justify-content: center;
    font-weight: bold;
    margin-bottom: 10px;
    transition: all 0.3s ease;
}

.step.active .step-number {
    background-color: var(--primary-color);
    color: white;
}

.step.completed .step-number {
    background-color: #28a745;
    color: white;
}

.step-title {
    font-size: 14px;
    text-align: center;
    color: #6c757d;
    transition: all 0.3s ease;
}

.step.active .step-title {
    color: var(--primary-color);
    font-weight: bold;
}

.step.completed .step-title {
    color: #28a745;
}

.booking-content {
    padding: 15px;
    min-height: 400px;
}


.booking-step {
    display: none;
    animation: fadeIn 0.5s ease;
}

.booking-step.active {
    display: block;
}

.booking-footer {
    padding: 20px;
    border-top: 1px solid #e3e6f0;
    display: flex;
    justify-content: space-between;
}

.category-card,
.service-card,
.employee-card {
    cursor: pointer;
    transition: all 0.3s ease;
    border: 2px solid transparent;
    margin-bottom: 20px;
    height: 100%;
}

.category-card:hover,
.service-card:hover,
.employee-card:hover {
    transform: translateY(-5px);
    box-shadow: 0 0.5rem 1rem rgba(0, 0, 0, 0.15);
}

.category-card.selected,
.service-card.selected,
.employee-card.selected {
    border-color: var(--primary-color);
    background-color: rgba(78, 115, 223, 0.1);
    border: 1px solid #4087ff !important;
}


.card-icon {
    font-size: 2rem;
    margin-bottom: 15px;
    color: var(--primary-color);
}

.time-slot {
    cursor: pointer;
    transition: all 0.2s ease;
    border: 1px solid #dee2e6;
    border-radius: 5px;
    padding: 10px;
    margin: 5px;
    text-align: center;
}

.time-slot:hover {
    background-color: rgba(78, 115, 223, 0.1);
}

.time-slot.selected {
    background-color: var(--primary-color);
    color: white;
    border-color: var(--primary-color);
}

.time-slot.disabled {
    opacity: 0.5;
    cursor: not-allowed;
    background-color: #f8f9fa;
}

.calendar-day {
    cursor: pointer;
    transition: all 0.2s ease;
}

.calendar-day:hover:not(.disabled) {
    background-color: rgba(78, 115, 223, 0.1);
}

.calendar-day.selected {
    background-color: var(--primary-color);
    color: white;
}

.calendar-day.disabled {
    opacity: 0.5;
    cursor: not-allowed;
    background-color: #f8f9fa;
}

.summary-item {
    margin-bottom: 15px;
    padding-bottom: 15px;
    border-bottom: 1px solid #e3e6f0;
}

@keyframes fadeIn {
    from {
        opacity: 0;
        transform: translateY(20px);
    }

    to {
        opacity: 1;
        transform: translateY(0);
    }
}

@keyframes slideIn {
    from {
        transform: translateX(50px);
        opacity: 0;
    }

    to {
        transform: translateX(0);
        opacity: 1;
    }
}

.animate-slide-in {
    animation: slideIn 0.5s ease forwards;
}

/* Progress bar between steps */
.booking-steps::before {
    content: '';
    /* position: absolute; */
    top: 80px;
    left: 20%;
    right: 20%;
    height: 2px;
    background-color: transparent;
    z-index: 0;
}

.progress-bar-steps {
    position: relative;
    height: 4px;
    background-color: #e0e0e0;
    /* margin: 0 40px; */
    top: -22px;
    z-index: 0;
}

.progress-bar-steps .progress {
    height: 100%;
    background-color: var(--primary-color);
    width: 0%;
    transition: width 0.5s ease;
}

@media(min-width:720px)
{
    .booking-content {
    padding: 30px;
    min-height: 400px;
}

}

</style><?php /**PATH C:\xampp\htdocs\Akash\Myra-skincare\resources\views/cart/style.blade.php ENDPATH**/ ?>