<?php $__env->startSection('title', $doctor->dr_name . ' | Myraluxa Aesthetic Pvt Ltd'); ?>

<?php $__env->startSection('content'); ?>
<main class="main">
    <div class="site-breadcrumb" style="background: url(<?php echo e(asset('assets/img/breadcrumb/01.jpg')); ?>)">
        <div class="container">
            <h2 class="breadcrumb-title">Doctor Details</h2>
            <ul class="breadcrumb-menu">
                <li><a href="<?php echo e(route('index')); ?>">Home</a></li>
                <li class="active">Doctor Details</li>
            </ul>
        </div>
    </div>

    <div class="team-single py-120">
        <div class="container">
            <div class="team-single-wrapper">
                <div class="row align-items-center">
                    <div class="col-lg-4">
                        <div class="team-single-img">
                            <img src="<?php echo e(asset('storage/doctors/' . $doctor->image)); ?>" alt>
                        </div>
                    </div>
                    <div class="col-lg-8">
                        <div class="team-single-content">
                            <div class="team-single-name">
                                <h3><?php echo e($doctor->dr_name); ?></h3>
                                <p><?php echo e($doctor->speciality); ?></p>
                            </div>
                            <div class="team-single-info">
                                <ul>
                                    <?php if($doctor->phone): ?>
                                    <li><span class="team-single-info-left">Phone:</span>
                                        <span class="team-single-info-right"><?php echo e($doctor->phone); ?></span></li>
                                    <?php endif; ?>

                                    <?php if($doctor->email): ?>
                                    <li><span class="team-single-info-left">Email:</span>
                                        <span class="team-single-info-right"><a href="mailto:<?php echo e($doctor->email); ?>"><?php echo e($doctor->email); ?></a></span></li>
                                    <?php endif; ?>

                                    <?php if($doctor->speciality): ?>
                                    <li><span class="team-single-info-left">Speciality:</span>
                                        <span class="team-single-info-right"><?php echo e($doctor->speciality); ?></span></li>
                                    <?php endif; ?>

                                    <?php if($doctor->experience): ?>
                                    <li><span class="team-single-info-left">Experience:</span>
                                        <span class="team-single-info-right"><?php echo e($doctor->experience); ?></span></li>
                                    <?php endif; ?>

                                    <?php if($doctor->degree): ?>
                                    <li><span class="team-single-info-left">Degree:</span>
                                        <span class="team-single-info-right"><?php echo e($doctor->degree); ?></span></li>
                                    <?php endif; ?>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="team-single-overview py-4">
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="team-single-overview-content">
                                <h4 class="mb-10">Doctor Introduction</h4>
                                <p><?php echo $doctor->dr_introduction; ?></p>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>
</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\Akash\Myra-skincare\resources\views/doctor-details.blade.php ENDPATH**/ ?>